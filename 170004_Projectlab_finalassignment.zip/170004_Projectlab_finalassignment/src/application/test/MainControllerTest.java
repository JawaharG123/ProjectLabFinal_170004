package application.test;

import application.DC;
import application.Main;
import application.MainController;
import org.junit.Test;

import static org.junit.Assert.*;

public class MainControllerTest {
@Test
   public void testOne() {

    Main.launch();
    MainController theMainControllerObject = new MainController();
    MainController.EBMSHubs ebmsHubs=theMainControllerObject.getCurrentlyCalledHub();
    assertTrue(ebmsHubs.equals(MainController.EBMSHubs.ADMIN_HUB));
}
public void calcu() {
	Main.launch();
	DC dcobject = new DC();
	dcobject.text_1 = 3;
	dcobject.text_1.getText();
	
	
}
}